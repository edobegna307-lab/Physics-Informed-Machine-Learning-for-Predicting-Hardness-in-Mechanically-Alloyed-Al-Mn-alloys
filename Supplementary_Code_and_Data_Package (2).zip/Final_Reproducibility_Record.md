# Reproducibility record

- Python 3.13.17; pandas 3.0.5, numpy 2.5.3, scipy 1.18.1, scikit-learn 1.9.1, seaborn 0.13.2, matplotlib 3.11.2, shap 0.54.1 (x86-64 Linux, 2 CPU cores).
- Verified run: `python3 Supplementary_Code_S1_analysis.py` exited with status 0 in a clean directory containing only the script and the CSV; its console output is `run_output_reference.log`.
- MD5 Supplementary_Code_S1_analysis.py: ed1a34dd8f7d38b4ad902da5d9d48a3c
- MD5 Supplementary_Data_S1_clean_dataset.csv: b15ade5a7483e1150280feaa81822e8e
- Random Forests: 500 trees, max depth 5, min samples per leaf 2, random_state 42. Global seed 42. Resampling seeds 42; repeated 5-fold seeds 0–19; surrogate seeds 0–9.
- No hyperparameter was tuned on any held-out fold. M2-RF versus M3-RF is the designated primary comparison and the other pairwise comparisons are exploratory. M3 carries the coherent-domain size d and density; the paired d + HP, HP-only and +aT versions are sensitivity analyses (Supplementary Table S17). Nothing was preregistered publicly.
