# Data curation record

The final dataset (`Supplementary_Data_S1_clean_dataset.csv`, 39 specimens) was prepared from the laboratory records of the original 42-specimen campaign as follows.

| # | Step | Scope |
|---|---|---|
| 1 | `grain_size` (integer nm) and `density` (two decimals, g·cm⁻³) are given at the precision recorded in the laboratory files. | Feeds M1 and M3; not M2. |
| 2 | Three specimens (hot press 450 °C, anneal 400 °C, 2 h; one per alloy) are excluded because their hardness, density and coherent-domain size coincide with values reported in Ref. [11]. | 42 → 39 specimens; tested in Supplementary Table S23. |
| 3 | The theoretical lattice parameter `aT` is one composition-based value per alloy (0.4045, 0.4046 and 0.4041 nm), as in [11]. | Used only in a sensitivity check. |
| 4 | The alloy label is standardised to `Al-Mn-Zr`, `Al-Mn-Zr-Ce` and `Al-Mn-Zr-Y`. | No numerical effect. |

Laboratory notebook identifiers were not available and are not listed. Supplementary Table S25 gives the specimen-level overlap with Ref. [11].
