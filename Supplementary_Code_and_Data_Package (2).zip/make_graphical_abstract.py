"""Graphical abstract generator. Hardness means/SD and retention are computed from the CSV;
the LOOCV/LOCO/LOAO R2 values of M2-RF are taken from the run output of Supplementary_Code_S1_analysis.py
(run_output_reference.log; Tables S11/S20)."""
import pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
df = pd.read_csv('Supplementary_Data_S1_clean_dataset.csv')
fam = ['Al-Mn-Zr', 'Al-Mn-Zr-Ce', 'Al-Mn-Zr-Y']
m = [df[df.alloy == a].microhardness.mean() for a in fam]
s = [df[df.alloy == a].microhardness.std() for a in fam]
r = [100 * (df[df.alloy == a].hardness450 / df[df.alloy == a].microhardness).mean() for a in fam]
R2 = {'LOOCV': 0.829, 'LOCO': 0.838, 'LOAO': -2.484}; BASE = -0.896
navy, B, O, G = '#1b2a4a', '#0072B2', '#D55E00', '#009E73'
fig = plt.figure(figsize=(13, 5), dpi=300)
fig.text(0.5, 0.945, 'High within-campaign accuracy does not imply transfer to an unseen alloy family', ha='center', fontsize=15, fontweight='bold', color=navy)
fig.text(0.5, 0.895, 'Mechanically alloyed Al–Mn–Zr, Al–Mn–Zr–Ce and Al–Mn–Zr–Y, hot-press consolidated', ha='center', fontsize=10.5, color='#555')
def card(x, w, title):
    fig.patches.append(FancyBboxPatch((x, 0.17), w, 0.66, boxstyle='round,pad=0.005,rounding_size=0.015', transform=fig.transFigure, fc='#f7f8fa', ec=navy, lw=1.5, zorder=-5))
    fig.text(x + w / 2, 0.775, title, ha='center', fontsize=12, fontweight='bold', color=navy)
card(0.02, 0.30, '1. Route and dataset'); card(0.345, 0.31, '2. Hardness by formulation'); card(0.68, 0.30, '3. What each validation shows')
a = fig.add_axes([0.04, 0.24, 0.26, 0.48]); a.patch.set_alpha(0); a.axis('off'); a.set_xlim(0, 1); a.set_ylim(0, 1)
for y, t in [(0.80, 'Ball milling, 20 h'), (0.52, 'Hot press, 350–450 °C'), (0.24, 'Anneal 350–450 °C, 2 or 4 h')]:
    a.add_patch(FancyBboxPatch((0.08, y - 0.09), 0.84, 0.18, boxstyle='round,pad=0.01,rounding_size=0.03', fc='white', ec=navy, lw=1.3))
    a.text(0.5, y, t, ha='center', va='center', fontsize=10.5, color=navy)
for y in (0.67, 0.39): a.annotate('', xy=(0.5, y - 0.07), xytext=(0.5, y + 0.01), arrowprops=dict(arrowstyle='-|>', color='#555'))
a.text(0.5, 0.03, f'{len(df)} specimens, {len(df)//3} per formulation\ndensity · XRD domain size · HV0.1', ha='center', va='center', fontsize=8.8, color='#555')
b = fig.add_axes([0.385, 0.30, 0.25, 0.40]); b.patch.set_alpha(0)
b.bar(range(3), m, yerr=s, color=[B, O, G], width=0.6, capsize=4, ecolor=navy)
for i in range(3):
    b.text(i, m[i] + s[i] + 10, f'{m[i]:.0f} HV', ha='center', fontsize=10, fontweight='bold', color=navy)
    b.text(i, m[i] / 2.2, f'{r[i]:.1f}%\nretained', ha='center', fontsize=8.5, color='white', fontweight='bold')
b.set_xticks(range(3)); b.set_xticklabels(['Al–Mn–Zr', '+Ce', '+Y'], fontsize=9.5); b.set_ylim(0, 540); b.set_ylabel('HV0.1', fontsize=9)
b.spines[['top', 'right']].set_visible(False)
fig.text(0.50, 0.195, 'Mean ± SD; retention after a common 450 °C treatment', ha='center', fontsize=8.3, color='#555')
c = fig.add_axes([0.73, 0.31, 0.23, 0.39]); c.patch.set_alpha(0)
v = list(R2.values()); c.bar(range(3), v, color=[B, B, O], width=0.6); c.axhline(0, color=navy, lw=1)
c.axhline(BASE, color='#555', ls='--', lw=1.2); c.text(-0.25, BASE - 0.2, f'grouped no-skill baseline −{abs(BASE):.2f}', fontsize=7.5, color='#555', ha='left', va='top')
for i, x in enumerate(v): c.text(i, x + (0.12 if x > 0 else -0.4), f'{x:.2f}'.replace('-', '−'), ha='center', fontsize=10, fontweight='bold', color=navy)
c.set_xticks(range(3)); c.set_xticklabels(['LOOCV', 'LOCO', 'LOAO\n(3 folds)'], fontsize=9); c.set_ylim(-3.2, 1.5); c.set_ylabel('R² (M2-RF)', fontsize=9)
c.spines[['top', 'right']].set_visible(False)
fig.text(0.83, 0.195, 'All models: LOAO R² −2.48 to −2.89', ha='center', fontsize=8.8, color=O, fontweight='bold')
fig.patches.append(FancyBboxPatch((0.02, 0.03), 0.96, 0.11, boxstyle='round,pad=0.005,rounding_size=0.015', transform=fig.transFigure, fc=navy, ec=navy))
fig.text(0.5, 0.085, 'Trends hold within the sampled formulations and process window. Transfer to an unseen alloy family is not supported\n(each family came from one parent powder batch, so family and batch are confounded).', ha='center', va='center', fontsize=10.5, color='white', fontweight='bold')
fig.savefig('Graphical_Abstract_Al-Mn-Zr-RE_Hardness.png', dpi=300); fig.savefig('Graphical_Abstract_Al-Mn-Zr-RE_Hardness.pdf')
from PIL import Image
Image.open('Graphical_Abstract_Al-Mn-Zr-RE_Hardness.png').convert('RGB').save('Graphical_Abstract_Al-Mn-Zr-RE_Hardness.tiff', dpi=(300, 300), compression='tiff_lzw')
