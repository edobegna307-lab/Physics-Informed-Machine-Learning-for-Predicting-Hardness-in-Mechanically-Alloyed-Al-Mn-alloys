"""
Supplementary Code S1

Structure-Process-Hardness Relationships in Mechanically Alloyed Al-Mn-Zr,
Al-Mn-Zr-Ce and Al-Mn-Zr-Y Alloys after Hot-Press Consolidation
M.A. Eshetu, A.S. Novikov -- Solid State Sciences

This single script reproduces every statistic, table and figure reported in
the manuscript and its Supplementary Information, starting from the raw
39-specimen dataset (Supplementary_Data_S1_clean_dataset.csv). Run with:

    python Supplementary_Code_S1_analysis.py

from the same directory as the CSV file. See README.md for the exact
package versions this was verified against, expected runtime (~8-10
minutes on one CPU core, dominated by the 5,000/10,000-iteration bootstrap
loops and the SHAP TreeExplainer call), and a map from each printed
block / saved figure to the manuscript table, figure or section it
reproduces.

Requires: pandas, numpy, scipy, scikit-learn, seaborn, matplotlib, shap
All randomness is seeded (global seed 42; per-routine seeds noted inline
and in README.md) so re-running reproduces the printed numbers exactly.
"""
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.dummy import DummyRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.svm import SVR
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import LeaveOneOut, LeaveOneGroupOut, KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.inspection import permutation_importance
import shap
import json

np.random.seed(42)

# =========================================================================
# 0. LOAD DATA AND ENGINEER FEATURES (Section 2.3)
# =========================================================================
df = pd.read_csv('Supplementary_Data_S1_clean_dataset.csv')
df['HP_term'] = df['grain_size'] ** -0.5
df['RE_Ce'] = (df['alloy'] == 'Al-Mn-Zr-Ce').astype(int)
df['RE_Y']  = (df['alloy'] == 'Al-Mn-Zr-Y').astype(int)
df['condition_id'] = (df['hotpress_temp'].astype(str) + '_' +
                       df['anneal_temp'].astype(str) + '_' + df['anneal_time'].astype(str))

y = df['microhardness'].values
n = len(df)
# Colour-blind-safe (Okabe-Ito) palette; Figure 1 additionally uses distinct marker shapes
colors = {'Al-Mn-Zr': '#0072B2', 'Al-Mn-Zr-Ce': '#D55E00', 'Al-Mn-Zr-Y': '#009E73'}
markers_ = {'Al-Mn-Zr': 'o', 'Al-Mn-Zr-Ce': 's', 'Al-Mn-Zr-Y': '^'}

print(f"Loaded n = {n} specimens, {df['alloy'].nunique()} alloy families, "
      f"{df['condition_id'].nunique()} unique process conditions.\n")

feat_M1 = ['HP_term', 'RE_Ce', 'RE_Y', 'density']
feat_M2 = ['hotpress_temp', 'anneal_temp', 'anneal_time', 'RE_Ce', 'RE_Y']
# M3 (primary, 7 features): M2 inputs plus density and the XRD coherent-domain size d (grain_size).
# The Hall-Petch-like transform HP = d^-1/2 is a deterministic function of d and is NOT included in
# the primary M3 (it would create a redundant predictor pair); the paired 8-feature version
# (d and HP together) is retained only as a Supplementary sensitivity analysis (feat_M3_paired).
# The theoretical lattice parameter aT is excluded from the primary M3 (it is one composition-based
# value per alloy); it is retained only in feat_M3_with_lattice as a sensitivity check.
feat_M3 = ['hotpress_temp', 'anneal_temp', 'anneal_time', 'grain_size',
           'density', 'RE_Ce', 'RE_Y']
feat_M3_paired = feat_M3 + ['HP_term']
feat_M3_with_lattice = feat_M3 + ['aT']
rf_params = dict(n_estimators=500, max_depth=5, min_samples_leaf=2, random_state=42)
loo = LeaveOneOut()

# =========================================================================
# 1. LOOCV PREDICTIONS FOR M1, M2, M3 AND CASE-RESAMPLING 95% INTERVALS
#    (main text Methods 2.5 and Results 3.3; Supplementary Table S21,
#    Supplementary Figure S8)
# =========================================================================
def loocv_predict(feat_cols, model_fn):
    X = df[feat_cols].values
    return cross_val_predict(model_fn(), X, y, cv=loo)

def bootstrap_ci(y_true, y_pred, n_boot=10000, seed=42):
    rng = np.random.default_rng(seed)
    idx_all = np.arange(len(y_true))
    r2s, rmses, maes = [], [], []
    for _ in range(n_boot):
        idx = rng.choice(idx_all, size=len(y_true), replace=True)
        yt, yp = y_true[idx], y_pred[idx]
        if np.std(yt) == 0:
            continue
        r2s.append(r2_score(yt, yp))
        rmses.append(np.sqrt(mean_squared_error(yt, yp)))
        maes.append(mean_absolute_error(yt, yp))
    ci = lambda a: np.percentile(a, [2.5, 97.5])
    return dict(r2=r2_score(y_true, y_pred), r2_ci=ci(r2s),
                rmse=np.sqrt(mean_squared_error(y_true, y_pred)), rmse_ci=ci(rmses),
                mae=mean_absolute_error(y_true, y_pred), mae_ci=ci(maes))

pred_M1 = loocv_predict(feat_M1, lambda: LinearRegression())
pred_M2 = loocv_predict(feat_M2, lambda: RandomForestRegressor(**rf_params))
pred_M3 = loocv_predict(feat_M3, lambda: RandomForestRegressor(**rf_params))

print("=== Supplementary Table S21: LOOCV performance, 95% case-resampling intervals (CRI) ===")
results_table3 = {}
for name, pred in [('M1', pred_M1), ('M2', pred_M2), ('M3', pred_M3)]:
    ci = bootstrap_ci(y, pred)
    results_table3[name] = ci
    print(f"{name}: R2={ci['r2']:.3f} [{ci['r2_ci'][0]:.3f},{ci['r2_ci'][1]:.3f}]  "
          f"RMSE={ci['rmse']:.1f} [{ci['rmse_ci'][0]:.1f},{ci['rmse_ci'][1]:.1f}]  "
          f"MAE={ci['mae']:.1f} [{ci['mae_ci'][0]:.1f},{ci['mae_ci'][1]:.1f}]")
print("(Note: the M2-OLS row of this table -- the ordinary-least-squares fit on the same 5 features as M2 -- "
      "is printed in Section 11 below, alongside the paired case-resampling tests.)")

print("\n=== Supplementary sensitivity: M3 with lattice parameter (aT) included (8 features) ===")
pred_M3_lat = loocv_predict(feat_M3_with_lattice, lambda: RandomForestRegressor(**rf_params))
ci_lat = bootstrap_ci(y, pred_M3_lat)
print(f"M3+lattice: R2={ci_lat['r2']:.3f} [{ci_lat['r2_ci'][0]:.3f},{ci_lat['r2_ci'][1]:.3f}]  "
      f"RMSE={ci_lat['rmse']:.1f}  MAE={ci_lat['mae']:.1f}  (vs. primary 7-feature M3 R2={results_table3['M3']['r2']:.3f})")

print("\n=== Supplementary Table S17: M3 variants (primary d-only; HP-only; paired d + HP) ===")
# Primary M3 carries d only. The two variants check whether replacing d by its deterministic
# transform HP = d^-1/2, or carrying both, changes LOOCV accuracy (Results 3.5).
feat_M3_HP_only = ['hotpress_temp', 'anneal_temp', 'anneal_time', 'HP_term',
                   'density', 'RE_Ce', 'RE_Y']
pred_M3_HP = loocv_predict(feat_M3_HP_only, lambda: RandomForestRegressor(**rf_params))
pred_M3_paired = loocv_predict(feat_M3_paired, lambda: RandomForestRegressor(**rf_params))
for lab, pr in [('Primary M3, d only (7-feat)', pred_M3), ('HP-only (7-feat)', pred_M3_HP), ('Paired d + HP (8-feat)', pred_M3_paired)]:
    print(f"{lab:30s}: R2={r2_score(y, pr):.3f}  RMSE={np.sqrt(mean_squared_error(y, pr)):.2f}  MAE={mean_absolute_error(y, pr):.2f}")

# Figure 1: LOOCV parity for M2
fig, ax = plt.subplots(figsize=(6, 6))
rmse_M2 = results_table3['M2']['rmse']
for alloy_name, c in colors.items():
    mask = (df['alloy'] == alloy_name).values
    ax.scatter(y[mask], pred_M2[mask], c=c, s=70, edgecolor='k', linewidth=0.5,
               label=alloy_name.replace('ZR', 'Zr'), alpha=0.85, zorder=3)
lims = [min(y.min(), pred_M2.min()) - 15, max(y.max(), pred_M2.max()) + 15]
ax.plot(lims, lims, 'k--', lw=1.3, label='Parity (y=x)', zorder=1)
ax.fill_between(lims, [l - rmse_M2 for l in lims], [l + rmse_M2 for l in lims],
                 color='gray', alpha=0.15, label=f'\u00b1RMSE ({rmse_M2:.1f} HV)', zorder=0)
ax.set_xlabel('Experimental micro-hardness (HV)'); ax.set_ylabel('Predicted micro-hardness (HV, LOOCV)')
ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_title(f'Deployable process+composition RF: LOOCV parity (n={n})\n'
             f'$R^2$={results_table3["M2"]["r2"]:.3f}, RMSE={rmse_M2:.1f} HV')
ax.legend(loc='upper left', fontsize=9); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig_S8_parity_M2RF.png', dpi=600); plt.savefig('fig_S8_parity_M2RF.pdf'); plt.close()

# =========================================================================
# 2. GROUPED CROSS-VALIDATION: LOCO AND LOAO (main text Methods 2.5 and
#    Results 3.4; Supplementary Table S20)
# =========================================================================
def grouped_cv(feat_cols, model_fn, group_col):
    X = df[feat_cols].values
    groups = df[group_col].values
    logo = LeaveOneGroupOut()
    return cross_val_predict(model_fn(), X, y, cv=logo, groups=groups)

print("\n=== Supplementary Table S20: grouped cross-validation (LOCO, LOAO) ===")
loao_preds = {}
for mname, feats, model_fn in [
    ('M1_linear', feat_M1, lambda: LinearRegression()),
    ('M2_RF', feat_M2, lambda: RandomForestRegressor(**rf_params)),
    ('M3_RF', feat_M3, lambda: RandomForestRegressor(**rf_params)),
]:
    pred_loco = grouped_cv(feats, model_fn, 'condition_id')
    pred_loao = grouped_cv(feats, model_fn, 'alloy')
    loao_preds[mname] = pred_loao
    loco_preds_all = globals().setdefault('loco_preds_all', {}); loco_preds_all[mname] = pred_loco
    rmse_loao = np.sqrt(mean_squared_error(y, pred_loao))
    mae_loao = mean_absolute_error(y, pred_loao)
    print(f"{mname}: LeaveOneConditionOut R2={r2_score(y, pred_loco):.3f}  "
          f"LeaveOneAlloyOut R2={r2_score(y, pred_loao):.3f}  "
          f"LOAO_RMSE={rmse_loao:.1f}  LOAO_MAE={mae_loao:.1f}")

# R2 under LOAO is computed on the POOLED out-of-fold predictions of all 39 specimens:
# R2 = 1 - sum((y - yhat)^2) / sum((y - mean(y_all))^2), i.e. the denominator is the total variance of all 39
# observed hardness values about their overall mean (sklearn.metrics.r2_score on the pooled predictions).
# LOAO has only THREE outer folds (one per alloy family), so its values are an informative but
# high-variance transferability stress test, not precise performance estimates.
print("\n=== Supplementary Table S24: LOAO per-held-out-family results (observed mean, predicted mean, signed bias, MAE, RMSE) ===")
pred_mean_loao_tmp = grouped_cv(feat_M2, lambda: DummyRegressor(strategy='mean'), 'alloy')
loao_preds['Mean_baseline'] = pred_mean_loao_tmp
for mname in ['M1_linear', 'M2_RF', 'M3_RF', 'Mean_baseline']:
    for alloy_name in ['Al-Mn-Zr', 'Al-Mn-Zr-Ce', 'Al-Mn-Zr-Y']:
        m = (df['alloy'] == alloy_name).values
        yo, yp = y[m], loao_preds[mname][m]
        print(f"  {mname:13s} | held-out {alloy_name:12s} | obs_mean={yo.mean():6.1f} pred_mean={yp.mean():6.1f} "
              f"bias={(yp - yo).mean():+7.1f} MAE={mean_absolute_error(yo, yp):6.1f} RMSE={np.sqrt(mean_squared_error(yo, yp)):6.1f} n={m.sum()}")

print("\n=== Main text Section 3.4: LOAO grouped no-skill (mean-predictor) baseline ===")
pred_mean_loao = grouped_cv(feat_M2, lambda: DummyRegressor(strategy='mean'), 'alloy')
r2_loao_base = r2_score(y, pred_mean_loao)
rmse_loao_base = np.sqrt(mean_squared_error(y, pred_mean_loao))
mae_loao_base = mean_absolute_error(y, pred_mean_loao)
print(f"  Mean predictor (grouped by alloy): R2={r2_loao_base:.3f}  RMSE={rmse_loao_base:.1f}  MAE={mae_loao_base:.1f}")
print(f"  (M2 LOAO RMSE={np.sqrt(mean_squared_error(y, loao_preds['M2_RF'])):.1f} is compared against this "
      f"GROUPED baseline, not the ordinary-LOOCV mean baseline in Supplementary Table S14.)")

# =========================================================================
# 3. REPEATED 5-FOLD CV, 20 SEEDS (main text Results 3.6, robustness check)
# =========================================================================
def repeated_kfold(feat_cols, model_fn, n_repeats=20, k=5):
    X = df[feat_cols].values
    r2s = []
    for seed in range(n_repeats):
        kf = KFold(n_splits=k, shuffle=True, random_state=seed)
        pred = cross_val_predict(model_fn(), X, y, cv=kf)
        r2s.append(r2_score(y, pred))
    return np.array(r2s)

r2_rep_M2 = repeated_kfold(feat_M2, lambda: RandomForestRegressor(**rf_params))
r2_rep_M3 = repeated_kfold(feat_M3, lambda: RandomForestRegressor(**rf_params))
print(f"\n=== Main text Results 3.6: repeated 5-fold CV, 20 seeds ===")
for name, arr in [('M2', r2_rep_M2), ('M3', r2_rep_M3)]:
    print(f"{name}: mean={arr.mean():.3f} sd={arr.std():.3f} median={np.median(arr):.3f} "
          f"IQR=[{np.percentile(arr,25):.3f},{np.percentile(arr,75):.3f}] "
          f"range=[{arr.min():.3f},{arr.max():.3f}] n={len(arr)}")

print("\n=== Supporting detail (Methods 2.2): per-alloy crystallite size / density (mean +/- SD) ===")
print(df.groupby('alloy')[['grain_size', 'density']].agg(['mean', 'std']))

# =========================================================================
# 4. BASELINE MODEL COMPARISON ON THE M2 FEATURE SET (main text Results 3.3;
#    Supplementary Table S14, Supplementary Figure S1)
# =========================================================================
X2 = df[feat_M2].values
baselines = {
    'Mean predictor': lambda: DummyRegressor(strategy='mean'),
    'OLS (linear)': lambda: LinearRegression(),
    'Ridge': lambda: make_pipeline(StandardScaler(), Ridge(alpha=1.0)),
    'PLS (2 comp.)': lambda: make_pipeline(StandardScaler(), PLSRegression(n_components=2)),
    'SVR (RBF)': lambda: make_pipeline(StandardScaler(), SVR(kernel='rbf', C=100, gamma='scale')),
    'Gaussian Process': lambda: make_pipeline(StandardScaler(), GaussianProcessRegressor(
        kernel=RBF() + WhiteKernel(), random_state=42, normalize_y=True)),
    'Gradient Boosting': lambda: GradientBoostingRegressor(n_estimators=200, max_depth=2, random_state=42),
    'Random Forest (M2)': lambda: RandomForestRegressor(**rf_params),
}
print("\n=== Supplementary Table S14: baseline comparison (M2 feature set), LOOCV ===")
baseline_r2 = {}
for bname, fn in baselines.items():
    pred = cross_val_predict(fn(), X2, y, cv=loo)
    r2 = r2_score(y, pred); rmse = np.sqrt(mean_squared_error(y, pred)); mae = mean_absolute_error(y, pred)
    baseline_r2[bname] = r2
    print(f"  {bname:20s} R2={r2:6.3f}  RMSE={rmse:6.1f}  MAE={mae:6.1f}")

fig, ax = plt.subplots(figsize=(8, 5))
short_names = {'Mean predictor':'Mean\npredictor','OLS (linear)':'OLS\n(linear)','Ridge':'Ridge',
               'PLS (2 comp.)':'PLS','SVR (RBF)':'SVR\n(RBF)','Gaussian Process':'Gaussian\nProcess',
               'Gradient Boosting':'Gradient\nBoosting','Random Forest (M2)':'Random\nForest'}
names = [short_names[k] for k in baseline_r2]; r2s = list(baseline_r2.values())
colors_bar = ['#999999' if 'Mean' in n else ('#D55E00' if 'Random' in n else '#4c72b0') for n in names]
bars = ax.bar(names, r2s, color=colors_bar, edgecolor='k')
ax.axhline(0, color='k', lw=0.8); ax.set_ylabel('LOOCV R\u00b2')
ax.set_title('Baseline model comparison (M2 feature set), LOOCV')
ax.grid(axis='y', alpha=0.3)
for b, v in zip(bars, r2s):
    ax.text(b.get_x() + b.get_width()/2, v + (0.03 if v >= 0 else -0.06), f"{v:.3f}", ha='center', fontsize=9)
plt.tight_layout(); plt.savefig('fig_S1_baseline_comparison.png', dpi=600); plt.savefig('fig_S1_baseline_comparison.pdf'); plt.close()

# =========================================================================
# 5. M1 COEFFICIENT BOOTSTRAP 95% INTERVALS (main text Results 3.5;
#    Supplementary Table S18, Supplementary Figure S3)
# =========================================================================
X1 = df[feat_M1].values
rng = np.random.default_rng(42)
n_boot = 5000
coef_names = feat_M1 + ['Intercept']
coefs_boot = np.zeros((n_boot, len(coef_names)))
for b in range(n_boot):
    idx = rng.choice(n, size=n, replace=True)
    Xb, yb = X1[idx], y[idx]
    lr = LinearRegression().fit(Xb, yb)
    coefs_boot[b, :-1] = lr.coef_
    coefs_boot[b, -1] = lr.intercept_

lr_full = LinearRegression().fit(X1, y)
coef_point = list(lr_full.coef_) + [lr_full.intercept_]
print("\n=== Supplementary Table S18: M1 coefficients, bootstrap percentile 95% CI (5,000 refits) ===")
for i, cname in enumerate(coef_names):
    lo, hi = np.percentile(coefs_boot[:, i], [2.5, 97.5])
    print(f"  {cname:10s}: {coef_point[i]:8.2f}  [{lo:8.2f}, {hi:8.2f}]")

fig, ax = plt.subplots(figsize=(6.5, 4.5))
names_c = feat_M1
pts = coef_point[:-1]
los, his = [], []
for i, cname in enumerate(names_c):
    lo, hi = np.percentile(coefs_boot[:, i], [2.5, 97.5])
    los.append(pts[i] - lo); his.append(hi - pts[i])
ax.errorbar(pts, names_c, xerr=[los, his], fmt='o', color='#4c72b0', ecolor='k', capsize=4, markersize=8)
ax.axvline(0, color='r', ls='--', lw=1)
ax.set_xlabel('Coefficient value (bootstrap 95% CI)')
ax.set_title('M1: coefficient estimates with bootstrap 95% CI (n_boot=5000)')
ax.grid(axis='x', alpha=0.3)
plt.tight_layout(); plt.savefig('fig_S3_coefficients.png', dpi=600); plt.savefig('fig_S3_coefficients.pdf'); plt.close()

# =========================================================================
# 6. RESIDUAL DIAGNOSTICS FOR M2-RF (Supplementary Information;
#    Supplementary Figure S2; feeds the Results 3.6 sensitivity check below)
# =========================================================================
resid = y - pred_M2
fig, axes = plt.subplots(2, 3, figsize=(15, 9))
ax = axes[0, 0]
for alloy_name, c in colors.items():
    mask = (df['alloy'] == alloy_name).values
    ax.scatter(pred_M2[mask], resid[mask], c=c, s=50, edgecolor='k', linewidth=0.4, label=alloy_name.replace('ZR','Zr'))
ax.axhline(0, color='k', ls='--', lw=1)
ax.set_xlabel('Predicted hardness (HV)'); ax.set_ylabel('Residual (HV)')
ax.set_title('(a) Residuals vs. predicted'); ax.legend(fontsize=7); ax.grid(alpha=0.3)

for ax, col, label in [(axes[0,1], 'hotpress_temp', 'Hot-press T (\u00b0C)'),
                        (axes[0,2], 'anneal_temp', 'Anneal T (\u00b0C)'),
                        (axes[1,0], 'anneal_time', 'Anneal time (h)')]:
    for alloy_name, c in colors.items():
        mask = (df['alloy'] == alloy_name).values
        ax.scatter(df[col][mask], resid[mask], c=c, s=50, edgecolor='k', linewidth=0.4)
    ax.axhline(0, color='k', ls='--', lw=1)
    ax.set_xlabel(label); ax.set_ylabel('Residual (HV)'); ax.grid(alpha=0.3)

axes[1,1].hist(resid, bins=12, color='#4c72b0', edgecolor='k')
axes[1,1].axvline(0, color='k', ls='--', lw=1)
axes[1,1].set_xlabel('Residual (HV)'); axes[1,1].set_ylabel('Count')
axes[1,1].set_title(f'(e) median|resid|={np.median(np.abs(resid)):.1f} HV, max={np.max(np.abs(resid)):.1f} HV')
axes[1,1].grid(alpha=0.3)

stats.probplot(resid, dist='norm', plot=axes[1,2])
axes[1,2].set_title('(f) Normal Q-Q plot')
plt.tight_layout(); plt.savefig('fig_S2_residual_diagnostics.png', dpi=600); plt.savefig('fig_S2_residual_diagnostics.pdf'); plt.close()
print(f"\n=== Supplementary Figure S2: residuals === median|resid|={np.median(np.abs(resid)):.1f} HV, max={np.max(np.abs(resid)):.1f} HV")

# =========================================================================
# 6b. SENSITIVITY: REFIT M1/M2/M3 WITHOUT THE TWO MOST INFLUENTIAL RESIDUALS
#     (main text Results 3.6)
# =========================================================================
influential_idx = np.argsort(-np.abs(resid))[:2]
print(f"\n=== Main text Results 3.6: two most influential (largest-residual) specimens ===")
for ii in influential_idx:
    print(f"  row {ii}: alloy={df['alloy'].iloc[ii]}, |resid|={abs(resid[ii]):.1f} HV")

keep_mask = np.ones(n, dtype=bool)
keep_mask[influential_idx] = False
df_sens = df[keep_mask].reset_index(drop=True)
y_sens = y[keep_mask]
loo_sens = LeaveOneOut()

print("=== Main text Results 3.6: LOOCV R2 with vs. without the two influential specimens ===")
for name, feats, model_fn in [
    ('M1', feat_M1, lambda: LinearRegression()),
    ('M2', feat_M2, lambda: RandomForestRegressor(**rf_params)),
    ('M3', feat_M3, lambda: RandomForestRegressor(**rf_params)),
]:
    X_full = df[feats].values
    pred_full = cross_val_predict(model_fn(), X_full, y, cv=loo)
    r2_full = r2_score(y, pred_full)
    X_sens = df_sens[feats].values
    pred_sens = cross_val_predict(model_fn(), X_sens, y_sens, cv=loo_sens)
    r2_sens = r2_score(y_sens, pred_sens)
    print(f"  {name}: R2_all={r2_full:.3f} (n={n})  ->  R2_without_2={r2_sens:.3f} (n={n - 2})")

lr_sens = LinearRegression().fit(df_sens[feat_M1].values, y_sens)
print("M1 coefficients, all data vs. without the two influential specimens:")
for cname, c_all, c_sens in zip(feat_M1, lr_full.coef_, lr_sens.coef_):
    print(f"  {cname:10s}: all={c_all:8.2f}   without_2={c_sens:8.2f}")
print(f"  {'Intercept':10s}: all={lr_full.intercept_:8.2f}   without_2={lr_sens.intercept_:8.2f}")

# =========================================================================
# 7. SHAP AND PERMUTATION IMPORTANCE (main text Results 3.5;
#    Supplementary Figure S6; exploratory attribution only, not used in
#    model selection or validation -- see main text caveat)
# =========================================================================
X3 = df[feat_M3].values
rf3_full = RandomForestRegressor(**rf_params).fit(X3, y)
rf2_full = RandomForestRegressor(**rf_params).fit(X2, y)
explainer = shap.TreeExplainer(rf3_full)
shap_values = explainer.shap_values(df[feat_M3])
fig = plt.figure(figsize=(7.5, 6))
shap.summary_plot(shap_values, df[feat_M3], show=False)
plt.tight_layout(); plt.savefig('fig_S6_shap_beeswarm.png', dpi=600, bbox_inches='tight'); plt.savefig('fig_S6_shap_beeswarm.pdf', bbox_inches='tight'); plt.close()

mean_abs_shap = pd.Series(np.abs(shap_values).mean(axis=0), index=feat_M3).sort_values(ascending=False)
print("\n=== Supplementary Figure S6: mean |SHAP| (M3) ===")
print(mean_abs_shap)

perm2 = permutation_importance(rf2_full, X2, y, n_repeats=100, random_state=42, scoring='r2')
print("\nPermutation importance (M2, drop in R2):")
for i, f in enumerate(feat_M2):
    print(f"  {f:16s}: {perm2.importances_mean[i]:.3f} +/- {perm2.importances_std[i]:.3f}")

# 7b. GROUPED PERMUTATION IMPORTANCE (out-of-fold, LOOCV). Features are permuted in groups so that
#     related inputs are treated together: process = (hot-press T, anneal T, anneal time);
#     formulation = (I(Ce), I(Y)); structure = (d, density).  For each LOOCV fold the model is fitted
#     on the other 38 specimens, the held-out specimen's group values are replaced by those of 200
#     randomly drawn training specimens (rows kept intact within the group), and the mean increase of the
#     squared error over all 39 folds is reported (exploratory attribution only).
print("\n=== Supplementary Table S26: grouped permutation importance (out-of-fold; increase in MSE, HV^2) ===")
rng_gp = np.random.default_rng(42)
groups_gp = {'process': ['hotpress_temp', 'anneal_temp', 'anneal_time'], 'formulation': ['RE_Ce', 'RE_Y'],
             'structure': ['grain_size', 'density']}
for mname, feats in [('M2-RF', feat_M2), ('M3-RF', feat_M3)]:
    base_se = 0.0; inc = {g: 0.0 for g in groups_gp if all(c in feats for c in groups_gp[g]) or g != 'structure'}
    inc = {g: 0.0 for g, cols in groups_gp.items() if any(c in feats for c in cols)}
    for tr, te in LeaveOneOut().split(df):
        rf = RandomForestRegressor(**rf_params).fit(df.iloc[tr][feats].values, y[tr])
        xte = df.iloc[te][feats].copy()
        base_se += (y[te][0] - rf.predict(xte.values)[0])**2
        for g, cols in groups_gp.items():
            cols = [c for c in cols if c in feats]
            if not cols: continue
            draw = df.iloc[tr][cols].sample(200, replace=True, random_state=int(rng_gp.integers(1e9))).values
            Xp = np.repeat(xte.values, 200, axis=0)
            idx = [feats.index(c) for c in cols]
            Xp[:, idx] = draw
            inc[g] += np.mean((y[te][0] - rf.predict(Xp))**2)
    print(f"  {mname}: baseline MSE={base_se/n:.1f}; " + "; ".join(f"{g}: +{(inc[g]-base_se)/n:.1f}" for g in inc))

# =========================================================================
# 8. FAMILY-SPECIFIC HALL-PETCH-LIKE REGRESSION + HETEROGENEITY TEST
#    (main text Results 3.5; Supplementary Figure S7)
# =========================================================================
print("\n=== Supplementary Figure S7: family-specific Hall-Petch-like regressions ===")
fig, ax = plt.subplots(figsize=(7, 5.5))
for alloy_name, c in colors.items():
    sub = df[df['alloy'] == alloy_name]
    x = sub['HP_term'].values; yy = sub['microhardness'].values
    slope, intercept, r, p, se = stats.linregress(x, yy)
    n_sub = len(x); tval = stats.t.ppf(0.975, n_sub - 2)
    ci_lo, ci_hi = slope - tval * se, slope + tval * se
    print(f"  {alloy_name:14s}: slope={slope:7.1f} [{ci_lo:7.1f},{ci_hi:7.1f}]  R2={r**2:.3f}  p={p:.4f}  n={n_sub}")
    xs = np.linspace(x.min(), x.max(), 50); pred_line = slope * xs + intercept
    x_mean = x.mean()
    s_yx = np.sqrt(np.sum((yy - (slope*x+intercept))**2) / (n_sub - 2))
    se_pred = s_yx * np.sqrt(1/n_sub + (xs-x_mean)**2 / np.sum((x-x_mean)**2))
    ax.plot(xs, pred_line, color=c, lw=1.8)
    ax.fill_between(xs, pred_line-tval*se_pred, pred_line+tval*se_pred, color=c, alpha=0.15)
    ax.scatter(x, yy, color=c, s=55, edgecolor='k', linewidth=0.4, label=f"{alloy_name.replace('ZR','Zr')} (p={p:.3f})")
ax.set_xlabel('Hall-Petch term, d^-1/2 (nm^-1/2)'); ax.set_ylabel('Micro-hardness (HV)')
ax.set_title('Family-specific Hall-Petch fits with 95% confidence bands')
ax.legend(fontsize=8.5); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig_S7_hallpetch.png', dpi=600); plt.savefig('fig_S7_hallpetch.pdf'); plt.close()

# heterogeneity F-test (common slope vs family-specific slopes)
X_int = pd.get_dummies(df['alloy'], drop_first=True).astype(float)
X_int['HP_term'] = df['HP_term'].values
for col in pd.get_dummies(df['alloy'], drop_first=True).columns:
    X_int[f'{col}_x_HP'] = X_int[col] * X_int['HP_term']
full_model = LinearRegression().fit(X_int.values, y)
ss_res_full = np.sum((y - full_model.predict(X_int.values))**2)
X_red = X_int.drop(columns=[c for c in X_int.columns if '_x_HP' in c])
red_model = LinearRegression().fit(X_red.values, y)
ss_res_red = np.sum((y - red_model.predict(X_red.values))**2)
df1 = X_int.shape[1] - X_red.shape[1]; df2 = n - X_int.shape[1] - 1
F = ((ss_res_red - ss_res_full)/df1) / (ss_res_full/df2)
p_interaction = 1 - stats.f.cdf(F, df1, df2)
print(f"\nHeterogeneity F-test: F({df1},{df2})={F:.3f}, p={p_interaction:.4f}")

# Pooled (not family-specific) correlation between the raw crystallite-size descriptor
# and hardness across all 39 specimens, ignoring alloy family -- quoted in Results 3.5
# as the weak pooled association that motivates the family-specific regressions above.
r_pooled, p_pooled = stats.pearsonr(df['grain_size'], y)
print(f"Pooled correlation (all 39 specimens, ignoring family): "
      f"r(grain_size, microhardness)={r_pooled:.3f}, p={p_pooled:.3f}")

# =========================================================================
# 9. EXPLORATORY UTS RELATIONSHIP AND PAIRED POST-TREATMENT-TO-AS-PROCESSED
#    HARDNESS RATIO (main text Results 3.1; Supplementary Figures S4-S5,
#    Supplementary Table S16). UTS was not used as a modelling target
#    anywhere in this work -- this correlation is exploratory context only.
# =========================================================================
df['post_treatment_ratio_pct'] = 100 * df['hardness450'] / df['microhardness']
r_uts = np.corrcoef(df['microhardness'], df['UTS'])[0, 1]
print(f"\n=== Supplementary Figure S4 (exploratory) === Pearson r (hardness vs UTS) = {r_uts:.3f}")

fig, ax = plt.subplots(figsize=(6, 5))
for alloy_name, c in colors.items():
    sub = df[df['alloy'] == alloy_name]
    ax.scatter(sub['microhardness'], sub['UTS'], c=c, label=alloy_name.replace('ZR','Zr'), s=60, edgecolor='k', linewidth=0.4)
ax.set_xlabel('Micro-hardness (HV)'); ax.set_ylabel('Ultimate tensile strength, UTS (MPa)')
ax.set_title(f'Hardness-tensile-strength relationship (r={r_uts:.2f})')
ax.legend(fontsize=9); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig_S4_uts_hv.png', dpi=600); plt.savefig('fig_S4_uts_hv.pdf'); plt.close()

fig, ax = plt.subplots(figsize=(6, 5))
for alloy_name, c in colors.items():
    sub = df[df['alloy'] == alloy_name]
    ax.scatter(sub['microhardness'], sub['hardness450'], c=c, label=alloy_name.replace('ZR','Zr'), s=60, edgecolor='k', linewidth=0.4)
lims2 = [df['hardness450'].min()-20, df['microhardness'].max()+20]
ax.plot(lims2, lims2, 'k--', lw=1, label='No degradation (y=x)')
ax.set_xlabel('As-processed micro-hardness (HV)'); ax.set_ylabel('Hardness after 450\u00b0C anneal (HV)')
ax.set_title('Paired post-treatment-to-as-processed hardness ratio')
ax.legend(fontsize=8); ax.grid(alpha=0.25)
plt.tight_layout(); plt.savefig('fig_S5_post_treatment_ratio.png', dpi=600); plt.savefig('fig_S5_post_treatment_ratio.pdf'); plt.close()
# Note: the SI's published Figure S4-S5 combines this panel and the UTS panel
# above into one side-by-side composite image; they are saved separately
# here so each plot's generating code stays self-contained.

print("\n=== Supplementary Table S16: paired post-treatment-to-as-processed hardness ratio by alloy family ===")
print(df.groupby('alloy')[['microhardness','hardness450','post_treatment_ratio_pct']].mean())

# =========================================================================
# 10. RETROSPECTIVE SURROGATE-RANKING ILLUSTRATION (Supplementary Information S15 --
#    retrospective ranking only, explicitly NOT a validated recommendation or design recommendation)
# =========================================================================
hp_range = np.linspace(350, 450, 21)
at_range = np.linspace(350, 450, 21)
att_range = np.array([2, 3, 4])
alloys_grid = [('Al-Mn-Zr', 0, 0), ('Al-Mn-Zr-Ce', 1, 0), ('Al-Mn-Zr-Y', 0, 1)]
HP2, AT2, ATT2 = np.meshgrid(hp_range, at_range, att_range, indexing='ij')
n2 = HP2.size
grid_frames = []
for aname, ce, yv in alloys_grid:
    Xq = pd.DataFrame({'hotpress_temp': HP2.ravel(), 'anneal_temp': AT2.ravel(),
                        'anneal_time': ATT2.ravel(), 'RE_Ce': np.full(n2, ce), 'RE_Y': np.full(n2, yv)})
    pred = rf2_full.predict(Xq)
    grid_frames.append(pd.DataFrame({'alloy': aname, 'hotpress_temp': Xq['hotpress_temp'],
                                      'anneal_temp': Xq['anneal_temp'], 'anneal_time': Xq['anneal_time'],
                                      'pred_HV': pred}))
grid_df = pd.concat(grid_frames, ignore_index=True).sort_values('pred_HV', ascending=False)
top = grid_df.iloc[0]
xtop = pd.DataFrame([[top['hotpress_temp'], top['anneal_temp'], top['anneal_time'],
                       1 if top['alloy']=='Al-Mn-Zr-Ce' else 0, 1 if top['alloy']=='Al-Mn-Zr-Y' else 0]],
                     columns=feat_M2)
tree_preds = np.array([t.predict(xtop.values)[0] for t in rf2_full.estimators_])
print(f"\n=== Main text Results 3.6: top surrogate-ranked candidate === {top['alloy']}, HP={top['hotpress_temp']:.0f}, "
      f"AT={top['anneal_temp']:.0f}, t={top['anneal_time']:.0f}h -> pred={top['pred_HV']:.1f} "
      f"+/- {1.96*tree_preds.std():.1f} HV (95% CI)")
best_exp = df.loc[df['microhardness'].idxmax()]
print(f"Best experimental specimen: {best_exp['alloy']}, HP={best_exp['hotpress_temp']}, "
      f"AT={best_exp['anneal_temp']}, t={best_exp['anneal_time']}h -> HV={best_exp['microhardness']}")

print(f"\n=== Supplementary Information: surrogate grid (retrospective ranking only) === {len(grid_df)} candidates: "
      f"3 alloys x hot-press 350-450 C (21 levels) x anneal 350-450 C (21 levels) x 2/3/4 h; training domain = realised 13 combinations per alloy")
print("  Observed hardness ranges per alloy (training domain upper bounds): " + ", ".join(f"{a}: max {df[df.alloy==a].microhardness.max():.0f} HV" for a in df.alloy.unique()))
print(f"  Surrogate LOOCV RMSE (M2-RF) = {np.sqrt(mean_squared_error(y, pred_M2)):.1f} HV (so differences between top candidates are far below prediction error)")
print("\n=== Supplementary Information: top-5 surrogate candidates ===")
top5 = grid_df.drop_duplicates(subset=['alloy', 'hotpress_temp', 'anneal_temp', 'anneal_time']).head(5)
for _, row in top5.iterrows():
    print(f"  {row['alloy']}, HP={row['hotpress_temp']:.0f}, AT={row['anneal_temp']:.0f}, "
          f"t={row['anneal_time']:.0f}h -> pred={row['pred_HV']:.1f} HV")
print(f"  Prediction spread across top 5: {top5['pred_HV'].max() - top5['pred_HV'].min():.2f} HV")

print("\n=== Supplementary Information: 10-seed robustness of top surrogate candidate ===")
seed_tops = []
for seed in range(10):
    rf_seed = RandomForestRegressor(**{**rf_params, 'random_state': seed})
    rf_seed.fit(df[feat_M2].values, y)
    preds_seed = []
    for aname, ce, yv in alloys_grid:
        Xq = pd.DataFrame({'hotpress_temp': HP2.ravel(), 'anneal_temp': AT2.ravel(),
                            'anneal_time': ATT2.ravel(), 'RE_Ce': np.full(n2, ce), 'RE_Y': np.full(n2, yv)})
        pred = rf_seed.predict(Xq)
        preds_seed.append(pd.DataFrame({'alloy': aname, 'hotpress_temp': Xq['hotpress_temp'],
                                         'anneal_temp': Xq['anneal_temp'], 'anneal_time': Xq['anneal_time'],
                                         'pred_HV': pred}))
    gdf_seed = pd.concat(preds_seed, ignore_index=True).sort_values('pred_HV', ascending=False)
    top_seed = gdf_seed.iloc[0]
    seed_tops.append((seed, top_seed['alloy'], top_seed['hotpress_temp'], top_seed['anneal_temp'],
                       top_seed['anneal_time'], top_seed['pred_HV']))
    print(f"  seed={seed}: {top_seed['alloy']}, HP={top_seed['hotpress_temp']:.0f}, "
          f"AT={top_seed['anneal_temp']:.0f}, t={top_seed['anneal_time']:.0f}h -> {top_seed['pred_HV']:.1f} HV")
same_alloy_hp = sum(1 for s in seed_tops if s[1] == 'Al-Mn-Zr' and s[2] == 450.0)
print(f"  Top candidate is Al-Mn-Zr at HP=450 in {same_alloy_hp}/10 seeds.")

print("\n=== Sections 1-10 complete (all main-text and SI point estimates/figures). "
      "Continuing to Sections 11-12 (paired tests, LOAO mechanics check). ===")

# =========================================================================
# 11. PAIRED CASE-RESAMPLING TESTS BETWEEN MODELS (main text Methods 2.5
#    defines the test; Results 3.3 reports the primary M2-RF-vs-M3-RF and
#    M2-OLS-vs-M2-RF empirical tail probabilities used in the manuscript)
# =========================================================================
X1 = df[feat_M1].values
pred_M2_OLS = cross_val_predict(LinearRegression(), X2, y, cv=loo)

print("\n=== Supplementary Table S21 (M2-OLS row): LOOCV performance, 95% case-resampling intervals (CRI) ===")
ci_ols = bootstrap_ci(y, pred_M2_OLS)
print(f"M2-OLS: R2={ci_ols['r2']:.3f} [{ci_ols['r2_ci'][0]:.3f},{ci_ols['r2_ci'][1]:.3f}]  "
      f"RMSE={ci_ols['rmse']:.1f} [{ci_ols['rmse_ci'][0]:.1f},{ci_ols['rmse_ci'][1]:.1f}]  "
      f"MAE={ci_ols['mae']:.1f} [{ci_ols['mae_ci'][0]:.1f},{ci_ols['mae_ci'][1]:.1f}]")

def paired_test(y_true, predA, predB, n_boot=10000, seed=42, labelA='A', labelB='B'):
    rng = np.random.default_rng(seed)
    n = len(y_true)
    errA = (y_true - predA)**2; errB = (y_true - predB)**2
    diff = errA - errB
    obs = diff.mean()
    boots = np.array([diff[rng.choice(n, n, replace=True)].mean() for _ in range(n_boot)])
    ci = np.percentile(boots, [2.5, 97.5])
    p = 2 * min((boots > 0).mean(), (boots < 0).mean())
    print(f"{labelA} vs {labelB}: mean(SE_{labelA}-SE_{labelB})={obs:.1f}  95% interval [{ci[0]:.1f},{ci[1]:.1f}]  empirical tail probability (two-sided)={p:.3f}")
    return obs, ci, p

print("\n=== Main text Methods 2.5 / Results 3.3: paired case-resampling tests, LOOCV squared errors ===")
pred_M3_loo = cross_val_predict(RandomForestRegressor(**rf_params), X3, y, cv=loo)
pred_M1_loo = cross_val_predict(LinearRegression(), X1, y, cv=loo)
paired_test(y, pred_M2, pred_M3_loo, labelA='M2-RF', labelB='M3-RF')     # PRIMARY, pre-specified: H1 test
paired_test(y, pred_M2_OLS, pred_M3_loo, labelA='M2-OLS', labelB='M3-RF')  # exploratory
paired_test(y, pred_M2_OLS, pred_M1_loo, labelA='M2-OLS', labelB='M1')     # exploratory
paired_test(y, pred_M2, pred_M1_loo, labelA='M2-RF', labelB='M1')          # exploratory
paired_test(y, pred_M2_OLS, pred_M2, labelA='M2-OLS', labelB='M2-RF')      # exploratory
paired_test(y, pred_M1_loo, pred_M3_loo, labelA='M1', labelB='M3-RF')      # exploratory

# =========================================================================
# 12. LOAO ENCODING-MECHANICS VERIFICATION (main text Results 3.4 --
#    confirms the Ce-indicator coefficient collapses to ~0 when the Ce
#    family is the withheld group, underlying the 2.1e-13 value quoted
#    in the manuscript's LOAO discussion)
# =========================================================================
train_mask = df['alloy'] != 'Al-Mn-Zr-Ce'
print("\n=== Main text Results 3.4: LOAO encoding mechanics, RE_Ce when Ce family held out ===")
print("Unique values in training set:", df.loc[train_mask, 'RE_Ce'].unique())
lr_check = LinearRegression().fit(df.loc[train_mask, feat_M1].values, df.loc[train_mask, 'microhardness'].values)
print("Fitted RE_Ce coefficient (should collapse to ~0):", dict(zip(feat_M1, lr_check.coef_))['RE_Ce'])

# =========================================================================
# 13. PROCESS-STRUCTURE-HARDNESS RELATIONSHIPS (main text Results 3.1,
#    Table 1, Figure 1). Descriptive, observational, within-family summaries
#    of how hardness, XRD-derived coherent-domain size, lattice parameter and
#    Archimedes density vary with the three process variables. n = 13 per
#    family; rank correlations are exploratory, two-sided and uncorrected for
#    multiple comparisons; the process matrix is a selected, non-factorial
#    subset (the four unrealised combinations are all 4 h anneals), so the
#    anneal-time contrast is confounded with the temperature mix.
# =========================================================================
fam_label = {'Al-Mn-Zr': 'Al-Mn-Zr', 'Al-Mn-Zr-Ce': 'Al-Mn-Zr-Ce', 'Al-Mn-Zr-Y': 'Al-Mn-Zr-Y'}
fam_order = ['Al-Mn-Zr', 'Al-Mn-Zr-Ce', 'Al-Mn-Zr-Y']
df['post_treatment_ratio_pct'] = 100 * df['hardness450'] / df['microhardness']

print("\n=== Main text Table 1: per-family structural/property summary (mean +/- SD, n=13 each) ===")
for a in fam_order:
    g = df[df['alloy'] == a]
    print(f"  {fam_label[a]:12s} d={g.grain_size.mean():.1f}+/-{g.grain_size.std():.1f} nm  "
          f"aT={g.aT.mean():.4f}+/-{g.aT.std():.4f}  rho={g.density.mean():.3f}+/-{g.density.std():.3f} g/cm3  "
          f"HV={g.microhardness.mean():.1f}+/-{g.microhardness.std():.1f}  "
          f"HV450={g.hardness450.mean():.1f}+/-{g.hardness450.std():.1f}  "
          f"ratio={g.post_treatment_ratio_pct.mean():.1f}%  (min-max HV {g.microhardness.min():.0f}-{g.microhardness.max():.0f})")

print("\n=== Main text Results 3.1: family means by process level ===")
for var, nm in [('microhardness', 'HV'), ('grain_size', 'd (nm)'), ('density', 'rho (g/cm3)')]:
    for fac in ['hotpress_temp', 'anneal_temp', 'anneal_time']:
        tab = df.pivot_table(index=fac, columns='alloy', values=var, aggfunc='mean')[fam_order]
        print(f"  {nm} by {fac}:")
        for lvl, row in tab.iterrows():
            print(f"    {lvl}: " + "  ".join(f"{fam_label[a]}={row[a]:.2f}" for a in fam_order))

print("\n=== Main text Results 3.1: within-family Spearman rank correlations (n=13, two-sided, uncorrected) ===")
for a in fam_order:
    g = df[df['alloy'] == a]
    for tgt in ['microhardness', 'grain_size', 'density']:
        out = []
        for fac in ['hotpress_temp', 'anneal_temp', 'anneal_time']:
            rho_s, p_s = stats.spearmanr(g[fac], g[tgt])
            out.append(f"{fac}: rho={rho_s:+.2f} (p={p_s:.3f})")
        print(f"  {fam_label[a]:12s} {tgt:13s} " + "; ".join(out))
    for x_, y_ in [('density', 'microhardness'), ('grain_size', 'density')]:
        rho_s, p_s = stats.spearmanr(g[x_], g[y_])
        print(f"  {fam_label[a]:12s} {x_} vs {y_}: rho={rho_s:+.2f} (p={p_s:.3f})")

print("\n=== Main text Results 3.1: 450 C ratio by anneal temperature and time (family means, %) ===")
for fac in ['anneal_temp', 'anneal_time']:
    tab = df.pivot_table(index=fac, columns='alloy', values='post_treatment_ratio_pct', aggfunc='mean')[fam_order]
    for lvl, row in tab.iterrows():
        print(f"  {fac}={lvl}: " + "  ".join(f"{fam_label[a]}={row[a]:.1f}" for a in fam_order))

# Figure 1 (main text): process dependence of hardness, coherent-domain size, density
fig, axes = plt.subplots(3, 3, figsize=(10.5, 8.6), sharey='row')
rows_ = [('microhardness', 'Micro-hardness (HV)'), ('grain_size', 'Coherent-domain size d (nm)'),
         ('density', 'Density (g\u00b7cm\u207b\u00b3)')]
cols_ = [('hotpress_temp', 'Hot-press temperature (\u00b0C)'), ('anneal_temp', 'Anneal temperature (\u00b0C)'),
         ('anneal_time', 'Anneal time (h)')]
rng_ = np.random.default_rng(42)
for i, (var, ylab) in enumerate(rows_):
    for j, (fac, xlab) in enumerate(cols_):
        ax = axes[i, j]
        lv = sorted(df[fac].unique())
        for k, a in enumerate(fam_order):
            g = df[df['alloy'] == a]
            off = (k - 1) * (0.07 * (max(lv) - min(lv)) if fac != 'anneal_time' else 0.12)
            ax.scatter(g[fac] + off + rng_.normal(0, 0.006 * (max(lv) - min(lv)), len(g)), g[var],
                       s=16, alpha=0.45, color=colors[a], linewidths=0)
            m_ = g.groupby(fac)[var].mean()
            ax.plot(np.array(m_.index) + off, m_.values, '-' + markers_[a], color=colors[a], ms=5, lw=1.6,
                    label=fam_label[a])
        ax.set_xticks(lv)
        ax.grid(alpha=0.25)
        if j == 0: ax.set_ylabel(ylab)
        if i == 2: ax.set_xlabel(xlab)
        for sp in ('top', 'right'): ax.spines[sp].set_visible(False)
h_, l_ = axes[0, 0].get_legend_handles_labels()
fig.legend(h_, l_, loc='upper center', ncol=3, frameon=False, fontsize=10)
plt.tight_layout(rect=(0, 0, 1, 0.96))
plt.savefig('fig_1_process_structure_hardness.png', dpi=600); plt.savefig('fig_1_process_structure_hardness.pdf'); plt.close()
print("Saved fig_1_process_structure_hardness.png")

# =========================================================================
# 14. DENSITY-POPULATION LEAVE-OUT SENSITIVITY (main text Section 3.4;
#     Supplementary Table S23)
#     The three densest remaining specimens (hot-press 450 C, anneal 450 C, 2 h;
#     one per alloy, >= 2.81 g/cm3) form a separate density population. They are
#     removed and the main results are recomputed. (Three further specimens that
#     overlapped an earlier publication were removed from the dataset before
#     analysis; see Data_Correction_Log.md.)
# =========================================================================
print("\n=== Supplementary Table S23: density-population leave-out sensitivity ===")
dense_mask = df['density'] >= 2.80
print(f"  Densest specimens (>=2.80 g/cm3): {int(dense_mask.sum())}")
def loo_loao_r2(sub, feats, model_fn):
    Xs, ys, gs = sub[feats].values, sub['microhardness'].values, sub['alloy'].values
    p_loo = cross_val_predict(model_fn(), Xs, ys, cv=LeaveOneOut())
    p_loao = cross_val_predict(model_fn(), Xs, ys, cv=LeaveOneGroupOut(), groups=gs)
    return r2_score(ys, p_loo), r2_score(ys, p_loao)
print("  subset                          n  | M1 LOOCV  M1 LOAO | M2-RF LOOCV  M2-RF LOAO | M3-RF LOOCV  M3-RF LOAO | M1 coef HP_term  M1 coef density")
for label, keep in [('All specimens', np.ones(n, dtype=bool)),
                    ('Without 3 densest specimens', ~dense_mask.values)]:
    sub = df[keep].reset_index(drop=True)
    r1 = loo_loao_r2(sub, feat_M1, lambda: LinearRegression())
    r2_ = loo_loao_r2(sub, feat_M2, lambda: RandomForestRegressor(**rf_params))
    r3 = loo_loao_r2(sub, feat_M3, lambda: RandomForestRegressor(**rf_params))
    lm = LinearRegression().fit(sub[feat_M1].values, sub['microhardness'].values)
    print(f"  {label:<32s}{len(sub):3d}  | {r1[0]:8.3f} {r1[1]:8.3f} | {r2_[0]:10.3f} {r2_[1]:11.3f} | {r3[0]:10.3f} {r3[1]:11.3f} | "
          f"{lm.coef_[0]:14.1f} {lm.coef_[3]:15.1f}")

# =========================================================================
# 15. ADDITIONAL FIGURES: process-condition coverage (Fig. S9) and LOAO family-level
#     observed vs. predicted means (Fig. S10)
# =========================================================================
fig, axes = plt.subplots(1, 2, figsize=(8, 3.8), sharey=True)
for ax, t in zip(axes, [2, 4]):
    M = np.zeros((3, 3))
    for i_, hp in enumerate([350, 400, 450]):
        for j_, at in enumerate([350, 400, 450]):
            M[i_, j_] = ((df.hotpress_temp == hp) & (df.anneal_temp == at) & (df.anneal_time == t)).sum()
    ax.imshow(M > 0, cmap='Blues', vmin=-0.3, vmax=1.4, origin='lower')
    for i_ in range(3):
        for j_ in range(3):
            ax.text(j_, i_, f"{int(M[i_, j_])} per\nfamily" if M[i_, j_] > 0 else 'absent', ha='center', va='center',
                    fontsize=9, color='k' if M[i_, j_] > 0 else '#B22222')
    ax.set_xticks(range(3)); ax.set_xticklabels([350, 400, 450]); ax.set_yticks(range(3)); ax.set_yticklabels([350, 400, 450])
    ax.set_xlabel('Anneal temperature (\u00b0C)'); ax.set_title(f'Anneal time {t} h')
axes[0].set_ylabel('Hot-press temperature (\u00b0C)')
fig.suptitle('Realised process conditions (13 of 18 combinations; 39 specimens)', fontsize=10)
plt.tight_layout(); plt.savefig('fig_S9_process_coverage.png', dpi=600); plt.savefig('fig_S9_process_coverage.pdf'); plt.close()

fig, ax = plt.subplots(figsize=(6.2, 4.2))
fams = ['Al-Mn-Zr', 'Al-Mn-Zr-Ce', 'Al-Mn-Zr-Y']
xpos = np.arange(3)
obs_m = [y[(df.alloy == a).values].mean() for a in fams]
ax.bar(xpos - 0.30, obs_m, 0.2, color='#555555', label='Observed family mean')
for k, (mn, lab, col) in enumerate([('M1_linear', 'M1', '#0072B2'), ('M2_RF', 'M2-RF', '#D55E00'), ('M3_RF', 'M3-RF', '#009E73')]):
    pm = [loao_preds[mn][(df.alloy == a).values].mean() for a in fams]
    ax.bar(xpos - 0.10 + 0.2 * k, pm, 0.2, color=col, label=f'{lab} (family withheld)')
ax.set_xticks(xpos); ax.set_xticklabels(['Al\u2013Mn\u2013Zr', '+Ce', '+Y'])
ax.set_ylabel('Mean micro-hardness (HV)'); ax.set_title('LOAO: observed vs. predicted family mean (3 folds only)')
ax.legend(fontsize=8, loc='upper right'); ax.grid(axis='y', alpha=0.25)
plt.tight_layout(); plt.savefig('fig_S10_loao_family_means.png', dpi=600); plt.savefig('fig_S10_loao_family_means.pdf'); plt.close()

# =========================================================================
# 16. MAIN-TEXT FIGURE 4 (Figure 2 in the version without XRD figures): LOAO predictions per withheld
#     family -- observed family mean, grouped no-skill baseline (training-fold mean) and model predictions
# =========================================================================
fig, axs = plt.subplots(1, 3, figsize=(9, 3.4), sharey=True)
cols_ = {'Grouped mean baseline': '#9a9a9a', 'M1': '#0072B2', 'M2-RF': '#D55E00', 'M3-RF': '#009E73'}
for i_, a in enumerate(fams):
    msk = (df.alloy == a).values
    preds_ = {'Grouped mean baseline': y[~msk].mean(), 'M1': loao_preds['M1_linear'][msk].mean(),
              'M2-RF': loao_preds['M2_RF'][msk].mean(), 'M3-RF': loao_preds['M3_RF'][msk].mean()}
    axs[i_].axhline(y[msk].mean(), color='k', lw=1.6, label='Observed family mean')
    for j_, (nm_, v_) in enumerate(preds_.items()):
        axs[i_].bar(j_, v_, color=cols_[nm_], width=0.7, label=nm_)
        axs[i_].text(j_, v_ + 6, f"{v_ - y[msk].mean():+.0f}", ha='center', fontsize=8)
    axs[i_].set_xticks(range(4)); axs[i_].set_xticklabels(['Base', 'M1', 'M2-RF', 'M3-RF'], fontsize=8)
    axs[i_].set_title(f'Withheld: {a}', fontsize=9.5); axs[i_].set_ylim(0, 500)
axs[0].set_ylabel('Mean hardness (HV0.1)')
h_, l_ = axs[0].get_legend_handles_labels()
fig.legend(h_, l_, loc='lower center', ncol=5, fontsize=8, frameon=False)
fig.tight_layout(rect=(0, 0.09, 1, 1))
fig.savefig('fig_4_loao_main.png', dpi=300); fig.savefig('fig_4_loao_main.pdf'); plt.close()

print("\n=== Supplementary Code S1 complete. ===")
